﻿namespace BuildingManagement.Data;

public class Class1
{
}
