namespace BuildingManagement.Web.Api;

public class ApiSettings
{
    public string BaseUrl { get; set; } = string.Empty;
}


