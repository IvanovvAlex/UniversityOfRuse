﻿namespace BuildingManagement.Common;

public class Class1
{

}
