﻿namespace BuildingManagement.Core;

public class Class1
{

}
