namespace BankAccountManager.Common.Clients
{
    public class ClientSearchRequest
    {
        public string? Name { get; set; }

        public string? Email { get; set; }

        public string? Phone { get; set; }
    }
}


